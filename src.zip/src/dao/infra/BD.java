package dao.infra;

public class BD {
	public static final String JDBC_DRIVER = "org.postgresql.Driver";
	public static final String SENHA = "postgres";
	public static final String USUARIO = "postgres";
	public static final String URL_CONEXAO = "jdbc:postgresql://localhost:5434/";
}
