package util;

public class Classificacao {
	//TODO: Hashmap com stream pra ordenacao
}
