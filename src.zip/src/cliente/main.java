package cliente;

public class main {

	public static void main(String[] args) {
		// TODO Fazer as chamadas...

	}

}
