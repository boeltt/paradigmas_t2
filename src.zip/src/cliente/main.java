package cliente;

public class main {

	public static void main(String[] args) {
		// TODO Fazer as chamadas...
		//Lembrar que Time precisa ser criado antes de Treinador e Jogador

	}

}
